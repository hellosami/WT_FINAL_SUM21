<!DOCTYPE html>
<html >
<head>

    
    <title></title>
</head>
<body>
    <a href="Home.php"><< Logout</a>
    <h1>Dashboard</h1>

    <span>Student</span>
    <ul>
        <li><a href="AllStudents.php">Show Students (Edit, Delete)</a></li>
        <li><a href="AddStudent.php">Add Student</a></li>
    </ul>

    <span>Department</span>
    <ul>
        <li><a href="AllDepartments.php">Show Departments (Edit, Delete)</a></li>
        <li><a href="AddDepartment.php">Add Department</a></li>
    </ul>
</body>
</html>
