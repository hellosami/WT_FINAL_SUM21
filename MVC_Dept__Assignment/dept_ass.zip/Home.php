<!DOCTYPE html>
<html>
<head>
    <title>Home Page</title>
</head>
<body>
    <h1>Home Page</h1>
    <ul>
        <li><a href="Login.php">Login</a></li>
    </ul>
</body>
</html>