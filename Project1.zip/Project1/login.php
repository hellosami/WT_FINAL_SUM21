

<?php include 'models/db_config.php';?>
<?php include 'controllers/LoginController.php';?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Company</title>
</head>
<body>

    <div class="main-content">

        <?php include 'includes/header.php'; ?>

        <br>

        <div class="content-wrapper">
            <form method="POST">
                <table>
                    <tr>
                        <td><label for="email">Email*</label></td>
                        <td>
                            <input type="text" name="email" id="email">
                            <span><?php echo $err_email; ?></span>
                        </td>
                    </tr>

                    <tr>
                        <td><label for="pass">Password*</label></td>
                        <td>
                            <input type="text" name="pass" id="pass">
                            <span><?php echo $err_pass; ?></span>
                        </td>
                    </tr>

                    <tr>
                        <td><label for="">Choose User*</label></td>
                        <td>
                            <br>
                            <select name="cuser" id="">
                                <option value="">Select ..</option>
                                <option value="renter">Renter</option>
                                <option value="rentee">Rentee</option>
                            </select>
                            <span><?php  ?></span>
                        </td>
                    </tr>

                    <tr>
                        <td></td>
                        <td><br><input class="default-btn" type="submit" name="btn-login" value="Log in"></td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
   

</body>
</html>