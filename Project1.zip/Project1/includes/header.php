<div class="navi-wrapper">
    <ul>
        <li onclick="location.href='index.php'">Home</li>
        <li onclick="location.href='company.php'">Company</li>
        <li onclick="location.href='#'">Services</li>
        <li onclick="location.href='#'">Blog</li>
        <li onclick="location.href='login.php'">Log in</li>
        <li onclick="location.href='signup.php'">Sign up</li>
    </ul>
</div>