<div class="navi-wrapper">
    <ul>
        <li class="<?php if($_GET['btn'] == '1') {echo "active";} ?>" onclick="location.href='index.php'">POST A RENT</li>
        <li class="<?php if($_GET['btn'] == '2') {echo "active";} ?>" onclick="location.href='my_posts.php'">MY POSTS</li>

        <li class="<?php if($_GET['btn'] == '3') {echo "active";} ?>" onclick="location.href='requests.php'">REQUESTS</li>

        <li class="<?php if($_GET['btn'] == '4') {echo "active";} ?>" onclick="location.href='my_profile.php'">MY PROFILE</li>

    </ul>
</div>