
<?php session_start(); ?>
<?php include '../models/db_config.php';?>
<?php include '../controllers/PostController.php';?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Renter Dashboard</title>
</head>
<body>

    <div class="main-content">

        <?php include 'includes/header.php'; ?>

        <br>

        <div class="content-wrapper">
            
            <div class="btn-xl-container">
                <div class="btn-xl" onclick="location.href='?btn=1&category=MotorBike'"><img src="image/icons/riding-fill.svg" alt=""></div>
                <div class="btn-xl" onclick="location.href='?btn=1&category=Car'"><img src="image/icons/roadster-fill.svg" alt=""></div>
                <div class="btn-xl" onclick="location.href='?btn=1&category=Truck'"><img src="image/icons/truck-line.svg" alt=""></div>
            </div>
            
            <br>
            <br>
            <div>
            <form action="" method="POST">
                <table>
                    <tr>
                        <td>Post Title*</td>
                        <td><input type="text" name="title"> <?php echo $err_title;?></td>
                    </tr>
                    <tr>
                        <td>Vehicle Category*</td>
                        <td><input type="text" name="category" value="<?php echo $_GET['category']; ?>" disabled></td>
                    </tr>
                    <tr>
                        <td>Rate*</td>
                        <td><input type="text" name="rate"> <?php echo $err_rate;?></td>
                    </tr>
                    <tr>
                        <td>Physical Condition*</td>
                        <td><input type="text" name="condition"> <?php echo $err_condition;?></td>
                    </tr>
                    <tr>
                        <td>Registration Number*</td>
                        <td><input type="text" name="rnumber"> <?php echo $err_rnumber;?></td>
                    </tr>
                    
                    <tr>
                        <td>Meter Reading*</td>
                        <td><input type="text" name="meter"> <?php echo $err_meter;?></td>
                    </tr>

                    <tr>
                        <td>Location*</td>
                        <td><input type="text" name="loc"> <?php echo $err_loc;?></td>
                    </tr>

                    <tr>
                        <td>Address*</td>
                        <td><input type="text" name="address"> <?php echo $err_address;?></td>
                    </tr>

                    <tr>
                        <td>Contact Number*</td>
                        <td><input type="text" name="contact"> <?php echo $err_contact;?></td>
                    </tr>

                    <tr>
                        <td>Terms and Conditions*</td>
                        <td><textarea name="tc" noresize></textarea> <?php echo $err_tc;?></td>
                    </tr>

                    <tr>
                        <td></td>
                        <td><input type="submit" name="post"></td>
                    </tr>

                </table>
                </form>
            </div>
        </div>
    </div>
   

</body>
</html>