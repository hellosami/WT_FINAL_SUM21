
<?php session_start(); ?>
<?php include '../models/db_config.php';?>
<?php include '../controllers/PostController.php';?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Renter Dashboard</title>
</head>
<body>

    <div class="main-content">

        <?php include 'includes/header.php'; ?>

        <br>

        <div class="content-wrapper">
            <div class="added-posts-wrapper">
                <ul class="added-posts">
                    <?php

                    $result = GetPostsByID($_SESSION['RID']);

                    if(count($result)  > 0) {
                    foreach($result as $key => $value) {
                    echo "
                    <br>
                    <li>
                    <div>
                    <span>".$value['title']."</span>
                    <span>Meter: ".$value['meter']."</span>
                    <span>Condition: ".$value['pcondition']."</span>
                    <span>Rate: ".$value['rate']."</span>
                    <span>Location: ".$value['loc']."</span>
                    <br>
                    <button>EDIT</button>
                    <button>DELETE</button>
                    </div>

                    </li>
                    ";
                    }
                    }
                    ?>
                </ul>
            </div>
                
      
        
        </div>
    </div>
   

</body>
</html>