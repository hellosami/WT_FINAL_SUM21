<div class="navi-wrapper">
    <ul>
        <li class="<?php if($_GET['btn'] == '1') {echo "active";} ?>" onclick="location.href='../index.php'">Search Rents</li>
        <li class="<?php if($_GET['btn'] == '2') {echo "active";} ?>" onclick="location.href='my_posts.php'">MY POSTS</li>

        <li class="<?php if($_GET['btn'] == '3') {echo "active";} ?>" onclick="location.href='#'">MY PROFILE</li>

    </ul>
</div>