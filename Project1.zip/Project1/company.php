


<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Company</title>
</head>
<body>

    <div class="main-content">

        <?php include 'includes/header.php'; ?>

        <br>

        <div class="content-wrapper">
            <p>
            Bproperty is the only property solutions provider in Bangladesh. 
            We cater to the needs of those seeking real estate services, with 
            a promise to make property search, renting & buying easier than ever. 
            We offer the easiest platform that enables anyone to buy, rent or sell 
            properties in the country.
            </p>
        </div>
    </div>
   

</body>
</html>