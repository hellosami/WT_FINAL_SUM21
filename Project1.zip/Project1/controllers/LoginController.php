<?php session_start(); ?>
<?php
    $hasError = false;
    $email = "";
    $err_email = "";

    $pass = "";
    $err_pass = "";

    $cuser = "";
    $err_cuser = "";

    // sa.mi@gmail.com
    function isEmail($str) {
        $arr = str_split($str);
  
        $flag1 = false;
        $flag2 = false;
        $flag3 = false;

        for($i = 0; $i < count($arr); $i++) {
            if($arr[$i] == '@') {
                $flag1 = true;
                break;
            }
        }

        for($i = $i + 1; $i < count($arr); $i++) {
            if($arr[$i] == '.') {
                $flag2 = true;
                break;
            }
        }




        for($i = 0; $i < count($arr); $i++) {
            if(ctype_space($arr[$i])) {
                $flag3 = true;
                break;
            }
        }


        if($flag1 && $flag2 && !$flag3) {
            return true;
        } else {
            return false;
        }

    }

    function isStrongPass($str) {
        $arr = str_split($str);
  
        $flag1 = false;
        $flag2 = false;
        $flag3 = false;
        $flag4 = false;

        for($i = 0; $i < count($arr); $i++) {
            if($arr[$i] == '@' || $arr[$i] == '$' || $arr[$i] == '!') {
                $flag1 = true;
            }

            if(ctype_upper($arr[$i])) {
                $flag2 = true;
            }

            if(ctype_lower($arr[$i])) {
                $flag3 = true;
            }

            if(is_numeric($arr[$i])) {
                $flag4 = true;
           
            }
        }



        if($flag1 && $flag2 && $flag3 && $flag4) {
            return true;
        } else {
            return false;
        }
    }

	if(isset($_POST["btn-login"])) {
		if(empty($_POST["email"])){
			$hasError = true;
			$err_email = "*This Field is Required!";
		}
        /*else if(!isEmail($_POST["email"])) {
            $hasError = true;
			$err_email = "*Email is Invalid!";
        }*/
		else{
			$email = $_POST["email"];
		}

        if(empty($_POST["pass"])){
			$hasError = true;
			$err_pass = "*This Field is Required!";
		}
        /*else if(strlen($_POST["pass"]) < 8){
			$hasError = true;
			$err_pass = "*Minimum 8 Characters!";
		}
        else if(!isStrongPass($_POST["pass"])){
			$hasError = true;
			$err_pass = "*Password Must Contain @/$/!, Combination of Uppercase and Lowercase Character!";
		}*/
		else{
			$pass = $_POST["pass"];
		}

        //
        /*if(empty($_POST["cuser"])){
			$hasError = true;
			$err_cuser = "*This Field is Required!";
		}
		else{
			$cuser = $_POST["cuser"];
		}*/

        $cuser = $_POST["cuser"];

		if(!$hasError) {
			$rs = Auth($email, $pass, $cuser);

			if ($rs == true){
                if($cuser == "renter") {

                    // Creating session
                    foreach($rs as $key => $value) {
                        $_SESSION['RID'] = $value['id'];
                    }

                    header("Location: renter/index.php?btn=1&category=MotorBike");
                }

                if($cuser == "rentee") {

                    // Creating session
                    foreach($rs as $key => $value) {
                        $_SESSION['RENTEE-ID'] = $value['id'];
                    }

                    header("Location: rentee/index.php?btn=1");
                }
				
			} else {
                echo "0";
            }
		}


	}

    function Auth($email, $pass, $cuser){


  

            $query = "SELECT * FROM SIGNUP WHERE EMAIL = '$email' && PASS = '$pass' && RENTAS = '$cuser';";
            return get($query);
  
            

        
       
    }

?>