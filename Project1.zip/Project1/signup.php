

<?php include 'models/db_config.php';?>

<?php include 'controllers/SignUpController.php';?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Company</title>
</head>
<body>

    <div class="main-content">

        <?php include 'includes/header.php'; ?>

        <br>

        <div class="content-wrapper">
            <form method="POST">
                <table >
                    <tr>
                        <td>Email*</td>
                        <td><input type="text" name="email"> <?php echo $err_email;?></td>
                    </tr>
                    <tr>
                        <td>Password*</td>
                        <td><input type="text" name="pass"> <?php echo $err_pass;?></td>
                    </tr>
                    <tr>
                        <td>Confirm Password*</td>
                        <td><input type="text" name="cpass"> <?php echo $err_cpass;?></td>
                    </tr>
                    <tr>
                        <td>Name*</td>
                        <td><input type="text" name="name"> <?php echo $err_name;?></td>
                    </tr>
                    <tr>
                        <td>Signing up as *</td>
                        <td>
                            <select name="rentas" >
                                <option value="">Select --</option>
                                <option value="renter">Renter</option>
                                <option value="rentee">Rentee</option>
                            </select> <?php echo $err_rentas;?>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="checkbox" name="agree"> I'm Not a Robot <?php echo $err_agree;?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="submit" name="signup"></td>
                    </tr>
                </table>
            </form>
            
        </div>
    </div>
   

</body>
</html>