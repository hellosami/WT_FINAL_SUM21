<div class="navi-wrapper">
    <ul>
        <li class="<?php if($_GET['btn'] == '1') {echo "active";} ?>" onclick="location.href='index.php'">DASHBOARD</li>
        <li class="<?php if($_GET['btn'] == '2') {echo "active";} ?>" onclick="location.href='report.php'">REPORT</li>
        <li class="<?php if($_GET['btn'] == '3') {echo "active";} ?>" onclick="location.href='send-notice.php'">SEND NOTICE</li>



    </ul>
</div>